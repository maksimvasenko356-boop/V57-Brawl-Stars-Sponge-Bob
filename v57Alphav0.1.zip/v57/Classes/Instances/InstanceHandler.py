class InstanceHandler:
    pass