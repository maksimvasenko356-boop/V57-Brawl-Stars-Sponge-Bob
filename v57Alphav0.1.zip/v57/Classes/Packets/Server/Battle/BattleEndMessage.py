from io import BytesIO

from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
import Configuration
from Database.DatabaseHandler import DatabaseHandler
import json
import Configuration
import random


OwnedBrawlersLatest = {
    0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 11, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
        78: {'CardID': 663, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        79: {'CardID': 671, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0, 'Mastery': 0, 'ClaimRewardMastery': 0},
        80: {'CardID': 730, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0, 'Mastery': 0, 'ClaimRewardMastery': 0},
        81: {'CardID': 748, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0, 'Mastery': 0, 'ClaimRewardMastery': 0}
}


class BattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        
        	
        kills = random.randint(1, 10)
        deads = random.randint(0, 3)
        MasteryPoints = 1000
        damages = random.randint(10000, 60000)
        
        self.writeLong(0, 1)
        self.writeLong(0, 1)
        self.writeVInt(fields["GameMode"]) # Battle End Game Mode
        self.writeVInt(fields["Rank"]) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVInt(fields["TokensGained"]) # Tokens Gained
        self.writeVInt(fields["TrophiesResult"]) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained (Pro League Points)
        self.writeVInt(0) # Doubled Tokens (Double Keys)
        self.writeVInt(fields["DoubleTokenEvent"]) # Double Token Event
        self.writeVInt(0) # Token Doubler Remaining (Double Keys Remaining)
        self.writeVInt(0) # game Lenght In Seconds
        self.writeVInt(0) # Epic Win Power Play Points Gained (op Win Points)
        self.writeVInt(0) # Championship Level Reached (CC Wins)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(fields["CoinShowEvent"]) # Coin Shower Event
        self.writeVInt(0) # Underdog Trophies
        self.writeVInt(0) # SD+ Win Trophies
        self.writeVInt(0) # SD+ Lose Trophies
        self.writeVInt(0) # Battle Result Type
        self.writeVInt(0) #wins brawlers trophies
        self.writeVInt(0) #dead lol trophies minus
        self.writeVInt(0) #Unk
        self.writeBoolean(False)# Unk
        self.writeBoolean(False)# Experience is Over
        self.writeBoolean(False)# Battle Tokens is Over
        self.writeBoolean(False)# Battle End State Off
        self.writeBoolean(True) # Trophies State
        self.writeBoolean(False)# Battle End State is Over
        self.writeBoolean(False)# Power Play Battle End
        self.writeVInt(-1)
        self.writeBoolean(False)

        self.writeVInt(fields["HeroesCount"]) #sub_65FED4
        for heroEntry in fields["Heroes"]:
            self.writeBoolean(heroEntry["IsPlayer"])
            self.writeBoolean(bool(heroEntry["Team"]))
            self.writeBoolean(bool(heroEntry["Team"]))
            self.writeByte(1)
            for i in range(1):
                self.writeDataReference(heroEntry["Brawler"]["ID"][0], heroEntry["Brawler"]["ID"][1])
            self.writeByte(1)
            for i in range(1):
                if (heroEntry["Brawler"]["SkinID"] is None):
                    self.writeVInt(0)
                else:
                    self.writeDataReference(heroEntry["Brawler"]["SkinID"][0], heroEntry["Brawler"]["SkinID"][1])
            self.writeByte(1)
            for i in range(1):
                self.writeVInt(1250)
            self.writeByte(1)
            for i in range(1):
                self.writeVInt(11)
            self.writeByte(1)
            for i in range(1):
                self.writeVInt(0)

            self.writeVInt(0)
            self.writeVInt(0)

            self.writeBoolean(heroEntry["IsPlayer"])
            if heroEntry["IsPlayer"]:
                self.writeLong(player.ID[0], player.ID[1])
            self.writeString(heroEntry["PlayerName"])
            self.writeVInt(100)
            self.writeVInt(28000000)
            self.writeVInt(43000000)
            self.writeVInt(-2)
            if heroEntry["IsPlayer"]:
                self.writeBoolean(True)
                self.writeVLong(5, 4181497)
                self.writeString('haccer club')
                self.writeDataReference(8, 16)
            else:
                self.writeBoolean(False)

            self.writeInt8(1)
            for i in range(1):

        	       	if heroEntry["IsPlayer"]:

        	       		for i,v in player.OwnedBrawlers.items():

        	       			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:

        	       				self.writeVInt(-1000 + v["MasteryPoints"]) # очки мастерства 
            self.writeInt8(1)
            self.writeVInt(MasteryPoints) #da
            

            self.writeInt16(5)
            self.writeInt16(3)
            self.writeInt(27328)
            self.writeInt(25659)

            self.writeDataReference(0)
            
            self.writeVInt(0)
            self.writeVInt(0)

        self.writeVInt(0) #maybe best battle moment
        
        self.writeVInt(0) #Cou
        """
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0) #Count
        """
        self.writeDataReference(0,0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1) #Count
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Play Again
        """
        self.writeDataReference(0)
        self.writeVInt(1)
        self.writeDataReference(16,0)
        self.writeVInt(1)
        self.writeDataReference(16,0)
        self.writeDataReference(16,0)
        """
        self.writeBoolean(True) # Logic Quests
        self.writeVInt(1) #Quests Count?
        self.writeVInt(85) 
        self.writeVInt(24) 
        self.writeVInt(1) 
        self.writeVInt(0) 
        self.writeVInt(3) 
        self.writeVInt(3)
        self.writeDataReference(16, 0)
        self.writeDataReference(16, 10)
        self.writeDataReference(16, 1)        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) 
        self.writeBoolean(False)
        self.writeBoolean(False)        
        self.writeVInt(28) 
        self.writeVInt(200) 
        self.writeDataReference(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0) 
        self.writeVInt(0)  
        self.writeVInt(0)  
        self.writeVInt(66462) 
        self.writeBoolean(False)
        self.writeBoolean(True)
        self.writeBoolean(False)
        self.writeVInt(24) 
        self.writeVInt(-1) 
        self.writeVInt(1719737999) 
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) #Quests Count 2?
        
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # sub_6BA330
        """
        self.writeVInt(1) #1
        self.writeVInt(1) #2
        self.writeVInt(1) #3
        self.writeVInt(1) #4
        self.writeVInt(1) #5
        self.writeVInt(1) #6
        self.writeVInt(1) #7
        self.writeVInt(1) #8
        self.writeVInt(1) #9
        self.writeVInt(1) #10
        self.writeVInt(1) #11
        self.writeVInt(1) #12
        self.writeVInt(1) #13
        self.writeVInt(1) #14
        self.writeVInt(1) #15
        self.writeVInt(1) #16
        self.writeVInt(1)#damn
        
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        #damn end
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1) #damn 2
        
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        #damn 2 End
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0) #1
        self.writeVInt(0) #2
        self.writeVInt(0) #3
        self.writeVInt(0) #4
        self.writeVInt(0) #5
        self.writeVInt(0) #6
        self.writeVInt(0) #7
        self.writeVInt(0) #8
        """
        
        self.writeVInt(0)
        self.writeBoolean(False) # true
        #a2 +16
        #vint a2 + 68
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0x0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # 0x0
        self.writeBoolean(False) # 0
        """'
        self.writeVInt(1)
        self.writeDataReference(16,0)
        """

        self.writeBoolean(False) # 0x0
        
        
        player.TrophiesGained += fields["TrophiesResult"]
        player.TokensGained += fields["TokensGained"] + fields["DoubleTokenEvent"]
        player.CoinsGained += fields["CoinShowEvent"]
        player.TokensGained += fields["RewardTokens"]
        player.CoinsGained += fields["RewardCoins"]
        try:
        	player.GemsGained
        except KeyError:
        	player.GemsGained = 0
        player.GemsGained += fields["RewardGems"]
        try:
        	player.StarPointsGained
        except KeyError:
        	player.StarPointsGained = 0
        player.StarPointsGained += fields["RewardStarPoints"]
        

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 23456

    def getMessageVersion(self):
        return self.messageVersion
